<?php
$data=file_get_contents('page_yuezhang_read.json');
echo $data;
?>