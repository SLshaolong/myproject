$(function() {
    $('.nav a').click(function() {
        $(this).addClass('on').siblings().removeClass("on");
    })
})