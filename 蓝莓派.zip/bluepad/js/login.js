$(function() {
    var btns = $('.login-res-select a');
    var boxs = $('.account-box');
    btns.map(function(index, element) {
        (function() {
            $(element).on('click', function() {
                $(this).addClass('on').siblings().removeClass('on');
                $(boxs[index]).addClass('on').siblings().removeClass('on');
            });
        }(index))
    })







    // 登录
    $('#login_btn').click(function() {
            var username = $('#login_accout').val();
            var password = $('#login_psd').val();
            if (username && password) {
                $.ajax({
                    url: 'http://localhost/bluepad/sever/login.php',
                    data: {
                        username: username,
                        password: password
                    },
                    type: 'post',
                    success: function(res) {
                        var data = JSON.parse(res);
                        if (data.msg == '登陆成功') {
                            localStorage.setItem('username', username);
                            window.location.href = 'index.html';
                        }

                    }
                })
            } else {
                alert('请输入用户名密码');
            }

        })
        // 注册
    $('#res_btn').click(function() {
        var username = $('#reg_accout').val();
        var password = $('#res_psd').val();
        if (username && password) {
            $.ajax({
                url: 'http://localhost/bluepad/sever/react.php',
                data: {
                    username: username,
                    password: password
                },
                type: 'post',
                success: function(res) {
                    var data = JSON.parse(res);
                    if (data.msg == '注册成功') {
                        localStorage.setItem('username', username);
                        window.location.href = 'index.html';
                    } else {
                        console.log('注册失败');
                    }

                }
            })
        } else {
            alert('请输入用户名密码');
        }

    })

})