import Vue from 'vue';
import { Cascader,Popup,Field,Button  } from 'vant';


Vue.use(Popup);
Vue.use(Field);
Vue.use(Cascader);
Vue.use(Button);