<?php
$name=$_POST['username'];
$word=$_POST['password'];
$mysql=mysqli_connect('localhost','root','sl3037302304','user');
if($mysql){
    mysqli_query($mysql,'set names utf8');
    $sql1="select * from bluepad where username='$name'";
    $result1=mysqli_query($mysql,$sql1);
    $data=mysqli_fetch_all($result1,MYSQLI_ASSOC);
    if($data){
        echo json_encode(array('msg'=>'用户名被占用,注册失败'));
    }else{
        $sql="insert into  bluepad values(null,'$name','$word')";
        $result=mysqli_query($mysql,$sql);
         if($result>0){
        echo json_encode(array('msg'=>'注册成功'));
        }else{
            echo json_encode(array('msg'=>'注册失败'));
        }
        }
    
    
}else{
    echo'数据库链接失败';
}


?>