<?php
$data=file_get_contents('http://localhost/bluepad/sever/chat.json');
echo $data;

?>