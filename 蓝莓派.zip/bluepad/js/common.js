$(function() {
    var username = localStorage.getItem('username');

    if (username) {
        $('.login-register').html("<a href='#' class='login' id='outline'>退出</a>" + "<a href='#' class='login' >" + username + "</a>");
    }
    $('#outline').click(function() {
        console.log(1);
        localStorage.removeItem('username');
        window.location.href = 'index.html';
    })


})