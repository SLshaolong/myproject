// app.js
App({

  data:{
      cityName:""
  }
})
