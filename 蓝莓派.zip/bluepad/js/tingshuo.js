$(function() {
    waterFlow()

    function waterFlow() {
        var all = $('.ts-card');
        // 获取所有子元素
        var rowNum = 4;
        // 一行可以摆放多少
        var colsHeightArr = [];
        // 存储每一行的高度
        all.map(function(index, element) {
            if (index < rowNum) {
                // 判断是否为第一行
                colsHeightArr.push($(element).height());
                // 获取当前高度放入数组中
            } else {
                // 获取数组中最小的值 将第二行第一个放在最小的
                var minHeightOfCols = Math.min.apply(null, colsHeightArr);
                // 获取最小的下标
                var minHeightOfIndex = colsHeightArr.indexOf(minHeightOfCols);
                all[index].style.position = "absolute";
                all[index].style.top = minHeightOfCols + 10 + "px";
                all[index].style.left = all.eq(minHeightOfIndex).position().left + "px";
                // 合并高度
                colsHeightArr[minHeightOfIndex] = colsHeightArr[minHeightOfIndex] + all[index].offsetHeight + 10;
                $('.ts-container').height(Math.max.apply(null, colsHeightArr))
            }
        })
    }

    window.onscroll = debounce(checkReachBottom, 300)
        // 防抖
    function debounce(fn, dealty) {
        var timer = null;
        return function() {
            if (timer) {
                clearTimeout(timer);
            }
            timer = setTimeout(fn, dealty)
        }
    }
    // 触底判断
    function checkReachBottom() {
        var scrollTop = $(window).scrollTop();
        var winHeight = $(window).height();
        var allchild = $('.ts-card');
        var lastBoxTop = allchild.eq(allchild.length - 1).offset().top + 240;
        if (lastBoxTop < scrollTop + winHeight) {
            $.ajax({
                type: 'get',
                url: 'http://localhost/bluepad/sever/tingshuo.php',
                success: function(res) {
                    var data = JSON.parse(res);
                    data.data.map(function(index, element) {
                        $('.ts-container').append("<div class='ts-card'>\
                        <div class='ts-card-header'>\
                            <img src='" + index.icon + "' class='ts-card-icon' alt=''>\
                            <span class='ts-card-name'>\
                                <p>" + index.title + "</p>\
                                <em>" + index.author + "</em>\
                            </span>\
                            <i class='tag-ts'>" + index.ts + "</i>\
                        </div>\
                        <img src='" + index.img + "' alt=''>\
                        <div class='ts-card-foot'>\
                            <p>" + index.desc + "</p>\
                            <span class='ts-cardfoot-icon'>\
                                <b class='ts-card-foot-1'></b><i>" + index.i + "</i>\
                                <b class='ts-card-foot-2'></b> <i>" + index.i + "</i>\
                            </span>\
                        </div>\
                    </div>")
                    })
                    waterFlow();
                }
            })
        }
    }
})