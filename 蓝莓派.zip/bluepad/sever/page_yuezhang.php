<?php
$data=file_get_contents('page_yuezhang.json');
echo $data;

?>