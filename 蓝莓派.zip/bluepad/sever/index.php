<?php
$json_data=file_get_contents("index.json");
echo $json_data;




?>