const base={
    baseUrl:'/',
    ncov:'ncov.php',
    nCoVNow:'http://api.tianapi.com/ncov/index',
    linecov:'http://iwenwiki.com/wapicovid19/ncovimg.php',
    city:'http://182.92.103.212/getcity'
}
export default base