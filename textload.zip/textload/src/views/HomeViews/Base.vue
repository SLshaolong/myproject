<template>
 <div class="box">
    <router-view></router-view>
 </div>
</template>

<script>

export default {

}
</script>

<style scoped>
.box{
    width: 100%;
    height: 100vh;
    box-sizing: border-box;
    background-image: url(../../assets/images/Homebac.png);
    background-size: 100%;
    background-position: bottom;
}
</style>