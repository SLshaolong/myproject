<?php
$name=$_POST['username'];
$word=$_POST['password'];

$mysql=mysqli_connect('locahost','user','password','bluepad');
if($mysql){
   mysqli_query($mysql,'set names utf8');
   $sql="select * from bluepad where username='$name' and password='$word'";
   $result=mysqli_query($mysql,$sql);
   $data=mysqli_fetch_all($result,MYSQLI_ASSOC);
   if(count($data)>0){
       echo json_encode(array('msg'=>'登陆成功','data'=>$data));
   }else{
    echo json_encode(array('msg'=>'登陆失败 用户名或密码错误'));
   }

}else{
    echo '数据库链接失败';
}



?>