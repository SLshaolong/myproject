$(function() {
    // 播放音乐
    function playMusic() {
        var audio = $('#audio')[0];
        if (audio.paused) {
            audio.play();
            $('#playImg').attr('src', 'images/pause.png')
        } else {
            audio.pause();
            $('#playImg').attr('src', 'images/play-btn_03.png')
        }
        var playTime = null;
        playTime = setInterval(function() {
            if (audio.paused) {
                clearInterval(playTime)
            }
            var playTime_s = audio.currentTime;

            // 获取当前播放的总时间
            var mTime = parseInt(playTime_s / 60);
            // 获取分钟
            var sTime = parseInt(playTime_s % 60);
            var totalTime_s = audio.duration;
            // 获取音乐总时长
            var mTime_total = parseInt(totalTime_s / 60);

            var sTime_total = parseInt(totalTime_s % 60);

            function checkTime(m, s) {
                if (m < 10) {
                    m = "0" + m;
                } else {
                    m += "";
                }
                if (s < 10) {
                    s = "0" + s;
                } else {
                    s += "";
                }
                return m + ":" + s
            }
            var pagePassTime = checkTime(mTime, sTime);
            var pageTotalTime = checkTime(mTime_total, sTime_total);
            $('#passTime').html(pagePassTime);
            $('#totalTime').html(pageTotalTime);
            // 播放音乐进度条
            var playedTimePercent = playTime_s / totalTime_s;
            if (totalTime_s - playTime_s > 0) {
                $('.progress-bar-passed').width(playedTimePercent * 100 + "%");
            } else {
                $('.progress-bar-passed').width(0 + "%");
            }
        }, 1000)

    }
    $('#playBtn').click(function() {
        playMusic();
    })


    // 获取文章内容
    $.ajax({
        type: 'get',
        url: 'http://localhost/BLUEPAD/sever/page_yuezhang.php',
        success: function(res) {
            var data = JSON.parse(res);
            $('.articalh3').html(data.artical.artical_title);
            $('.blog-details-content').html(decodeURI(data.artical.artical_cont));
            for (var i = 0; i < data.labels.length; i++) {
                $('.blog-details-labels').append(
                    "<span class='label'>" + data.labels[i] + "</span>"
                )
            }
        }
    })

    // 获取相关阅读
    $.ajax({
        type: 'get',
        url: 'http://localhost/bluepad/sever/page_yuezhang_read.php',
        success: function(res) {
            var data = JSON.parse(res);
            for (var i = 0; i < data.readList.length; i++) {
                $('.related-read-content').append("\
             <div class='related-content-show'>\
            <a href='#'>\
                <img class='related-read-pic' src='" + data.readList[i].img + "' >\
                <p class='related-read-summary'>" + data.readList[i].title + "</p>\
            </a>\
        </div>")
            }
        }
    })






})