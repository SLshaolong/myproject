<?php
$json_data=file_get_contents('index_youji.json');
echo $json_data;
?>

