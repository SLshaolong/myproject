<?php
$page=$_GET['page'];
if($page){
    $data=file_get_contents('pad.json');
    echo $data;
}


?>