$(function() {
    var mySwiper = new Swiper('.swiper', {
            loop: true, // 循环模式选项
            pagination: {
                el: '.swiper-pagination',
            },

        })
        //网络接口
    $.ajax({
            type: 'get',
            url: 'http://localhost/BLUEPAD/sever/index.php',
            success: function(res) {
                var jso = JSON.parse(res);
                $('.s1 h3').html(jso.banner[0].title);
                $('.s1 p').html(jso.banner[0].content);
                $('.s2 h3').html(jso.banner[1].title);
                $('.s2 p').html(jso.banner[1].content);
                $('.s3 h3').html(jso.banner[2].title);
                $('.s3 p').html(jso.banner[2].content);
            }
        })
        // 获取乐章
    $.ajax({
            type: 'get',
            url: 'http://localhost/BLUEPAD/sever/index_yuezhang.php',
            success: function(res) {
                var data = JSON.parse(res);
                for (var i = 0; i < data.yuezhang.length; i++) {
                    $('.d-list').append("\
                <li class=' d-item'>\
                <div class='item-img'>\
                    <a href='#'>\
                        <img src='" + data.yuezhang[i].img + "' alt=''>\
                    </a>\
                </div>\
                <div class='item-text'>\
                    <a href='#' class='text-title'>" + data.yuezhang[i].title + "</a>\
                    <a href='#' class='text-author'>" + data.yuezhang[i].username + "</a>\
                    <p class='text-content'>\
                        " + data.yuezhang[i].desc + "\
                    </p>\
                    <div class='comment'>\
                        <i class='zan-num'>" + data.yuezhang[i].zan + "</i>\
                        <i class='zan-icon'></i>\
                        <i class='comment-num'>" + data.yuezhang[i].comment + "</i>\
                        <i class='comment-icon'></i>\
                    </div>\
                </div>\
            </li>\
                ")
                }
            }

        })
        // 游记
    $.ajax({
        type: 'get',
        url: 'http://localhost/BLUEPAD/sever/index_youji.php',
        success: function(res) {
            var data = JSON.parse(res);
            for (var i = 0; i < data.youji.length; i++) {
                $('.note-list').append("<li class='note'>\
                <a href='#'>\
                    <img src=' " + data.youji[i].img + " ' alt=''>\
                    <p class='note-title'>" + data.youji[i].title + "</p>\
                    <p class='note-author'>" + data.youji[i].author + "</p>\
                    <div class='note-desc'>\
                        <p class='note-desc-content'>\
                            " + data.youji[i].desc + "\
                        </p>\
                    </div>\
                </a>\
            </li>")
            }
        }
    })
})