const  base={
    baseUrl:'http://182.92.103.212:3003',
    getUserInfo:'/api/load',
    registUser:'/api/regist',
    SelectList:'/api/selectList',
    Detail:'/api/detail',
    allData:'/api/getall',
    insert:'/api/insert',
    Delete:'/api/delete'

}
export default base